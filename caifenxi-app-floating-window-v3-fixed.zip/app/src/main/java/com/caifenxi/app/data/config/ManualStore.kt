package com.caifenxi.app.data.config

import com.caifenxi.app.data.db.dao.ManualMarkDao
import com.caifenxi.app.data.db.entity.ManualMarkEntity
import com.caifenxi.app.domain.model.ManualMark

class ManualStore(private val dao: ManualMarkDao) {

    suspend fun load(lotteryKey: String): Map<String, ManualMark> {
        return dao.getByLottery(lotteryKey)
            .map { it.toDomain() }
            .associateBy { it.category }
    }

    suspend fun save(mark: ManualMark) {
        dao.upsert(ManualMarkEntity.fromDomain(mark))
    }

    suspend fun clear(lotteryKey: String) {
        dao.deleteByLottery(lotteryKey)
    }
}
