package com.caifenxi.app.data.db.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.caifenxi.app.data.db.entity.CustomPlanEntity

@Dao
interface CustomPlanDao {
    @Query("SELECT * FROM custom_plans WHERE lotteryKey = :lotteryKey ORDER BY createdAt ASC")
    suspend fun getByLottery(lotteryKey: String): List<CustomPlanEntity>

    @Query("SELECT * FROM custom_plans ORDER BY lotteryKey ASC, createdAt ASC")
    suspend fun getAll(): List<CustomPlanEntity>

    @Query("SELECT * FROM custom_plans WHERE lotteryKey = :lotteryKey AND enabled = 1 ORDER BY createdAt ASC")
    suspend fun getEnabledByLottery(lotteryKey: String): List<CustomPlanEntity>

    @Query("SELECT * FROM custom_plans WHERE planId = :planId LIMIT 1")
    suspend fun getById(planId: String): CustomPlanEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(plan: CustomPlanEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(plans: List<CustomPlanEntity>)

    @Query("DELETE FROM custom_plans WHERE planId = :planId")
    suspend fun deleteById(planId: String)

    @Query("DELETE FROM custom_plans WHERE lotteryKey = :lotteryKey")
    suspend fun deleteByLottery(lotteryKey: String)

    @Query("DELETE FROM custom_plans")
    suspend fun deleteAll()
}
