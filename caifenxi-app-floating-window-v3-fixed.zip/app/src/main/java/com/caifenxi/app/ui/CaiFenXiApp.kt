package com.caifenxi.app.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.AttachMoney
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.ListAlt
import androidx.compose.material.icons.filled.Science
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.sp
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.caifenxi.app.ui.screens.BetScreen
import com.caifenxi.app.ui.screens.HistoryScreen
import com.caifenxi.app.ui.screens.HomeScreen
import com.caifenxi.app.ui.screens.LabScreen
import com.caifenxi.app.ui.screens.PlanScreen
import com.caifenxi.app.ui.screens.PredictScreen
import com.caifenxi.app.ui.screens.SettingsScreen

private enum class Tab(val route: String, val label: String, val icon: ImageVector) {
    Home("home", "首页", Icons.Filled.Home),
    Predict("predict", "分析", Icons.Filled.Analytics),
    Stats("stats", "战绩", Icons.Filled.TrendingUp),
    Lab("lab", "实验室", Icons.Filled.Science),
    Plan("plan", "计划", Icons.Filled.ListAlt),
    Bet("bet", "挂机", Icons.Filled.AttachMoney),
    Settings("settings", "设置", Icons.Filled.Settings),
}

@Composable
fun CaiFenXiApp(viewModel: MainViewModel) {
    val navController = rememberNavController()
    val backStack by navController.currentBackStackEntryAsState()
    val currentRoute = backStack?.destination?.route

    Scaffold(
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                Tab.entries.forEach { tab ->
                    NavigationBarItem(
                        selected = currentRoute == tab.route,
                        onClick = {
                            navController.navigate(tab.route) {
                                popUpTo(navController.graph.findStartDestination().id) {
                                    saveState = true
                                }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = { Icon(tab.icon, contentDescription = tab.label) },
                        label = { Text(tab.label, fontSize = 11.sp) }
                    )
                }
            }
        }
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = Tab.Home.route,
            modifier = Modifier.padding(padding)
        ) {
            composable(Tab.Home.route) { HomeScreen(viewModel) }
            composable(Tab.Predict.route) { PredictScreen(viewModel) }
            composable(Tab.Stats.route) { HistoryScreen(viewModel) }
            composable(Tab.Lab.route) { LabScreen(viewModel) }
            composable(Tab.Plan.route) { PlanScreen(viewModel) }
            composable(Tab.Bet.route) { BetScreen(viewModel) }
            composable(Tab.Settings.route) { SettingsScreen(viewModel) }
        }
    }
}
