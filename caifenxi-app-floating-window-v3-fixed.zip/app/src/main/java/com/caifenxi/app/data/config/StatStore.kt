package com.caifenxi.app.data.config

import com.caifenxi.app.data.db.dao.StatDao
import com.caifenxi.app.data.db.entity.StatEntity
import com.caifenxi.app.domain.model.CategoryStats
import com.caifenxi.app.domain.model.StatRecord
import com.caifenxi.app.domain.model.StatsSummary

class StatStore(private val dao: StatDao) {

    suspend fun loadAll(lotteryKey: String? = null): List<StatRecord> {
        return if (lotteryKey == null) {
            // 加载所有彩种的记录(需要遍历所有彩种)
            // 简化实现:返回空列表,实际使用时应传入 lotteryKey
            emptyList()
        } else {
            dao.getByLottery(lotteryKey).map { it.toDomain() }
        }
    }

    suspend fun saveAll(list: List<StatRecord>) {
        // 批量保存,先删除旧的,再插入新的
        if (list.isEmpty()) return
        val lotteryKey = list.first().lotteryKey
        dao.deleteByLottery(lotteryKey)
        dao.upsertAll(list.map { StatEntity.fromDomain(it) })
    }

    suspend fun upsert(record: StatRecord) {
        dao.upsert(StatEntity.fromDomain(record))
    }

    suspend fun clear(lotteryKey: String? = null) {
        if (lotteryKey == null) {
            dao.deleteAll()
        } else {
            dao.deleteByLottery(lotteryKey)
        }
    }

    suspend fun summary(lotteryKey: String): StatsSummary {
        val all = loadAll(lotteryKey)
        val settled = all.filter { it.result == "对" || it.result == "错" }
        val hit = settled.count { it.result == "对" }
        val miss = settled.count { it.result == "错" }
        val pending = all.count { it.result == "待开" }

        val chrono = StreakCalc.chronoOf(settled, { it.issue }, { it.createdAt }, { it.id })
        val (recent, maxH, maxM) = StreakCalc.streaksOf(chrono.map { it.result })

        // 分组(分类/算法)各自的完整统计:连击 + 两期/三期窗口率
        fun group(key: (StatRecord) -> String): Map<String, CategoryStats> {
            return settled.groupBy(key).mapValues { (_, rows) ->
                val gChrono = StreakCalc.chronoOf(rows, { it.issue }, { it.createdAt }, { it.id })
                StreakCalc.buildCategoryStats(gChrono.map { it.result })
            }
        }

        val results = chrono.map { it.result }
        val (w2, w2Hit, w2Miss) = StreakCalc.windowRates(results, 2)
        val (w3, w3Hit, w3Miss) = StreakCalc.windowRates(results, 3)

        return StatsSummary(
            total = all.size,
            pending = pending,
            hit = hit,
            miss = miss,
            hitRate = if (hit + miss == 0) 0.0 else hit.toDouble() / (hit + miss),
            byCategory = group { it.category },
            byAlgo = group { it.algoId },
            recentStreak = recent,
            maxHitStreak = maxH,
            maxMissStreak = maxM,
            twoWindows = w2,
            twoHitWindows = w2Hit,
            twoMissWindows = w2Miss,
            twoHitRate = if (w2 > 0) w2Hit.toDouble() / w2 else 0.0,
            twoMissRate = if (w2 > 0) w2Miss.toDouble() / w2 else 0.0,
            threeWindows = w3,
            threeHitWindows = w3Hit,
            threeMissWindows = w3Miss,
            threeHitRate = if (w3 > 0) w3Hit.toDouble() / w3 else 0.0,
            threeMissRate = if (w3 > 0) w3Miss.toDouble() / w3 else 0.0
        )
    }
}
