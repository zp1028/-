package com.caifenxi.app.data.db.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.caifenxi.app.data.db.entity.StatEntity

@Dao
interface StatDao {
    @Query("SELECT * FROM stats WHERE lotteryKey = :lotteryKey ORDER BY createdAt DESC")
    suspend fun getByLottery(lotteryKey: String): List<StatEntity>

    @Query("SELECT * FROM stats ORDER BY lotteryKey ASC, createdAt DESC")
    suspend fun getAll(): List<StatEntity>

    @Query("SELECT * FROM stats WHERE lotteryKey = :lotteryKey AND category = :category ORDER BY createdAt DESC")
    suspend fun getByLotteryAndCategory(lotteryKey: String, category: String): List<StatEntity>

    @Query("SELECT * FROM stats WHERE lotteryKey = :lotteryKey AND issue = :issue AND category = :category LIMIT 1")
    suspend fun getByLotteryIssueCategory(lotteryKey: String, issue: String, category: String): StatEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(stat: StatEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(stats: List<StatEntity>)

    @Query("DELETE FROM stats WHERE lotteryKey = :lotteryKey")
    suspend fun deleteByLottery(lotteryKey: String)

    @Query("DELETE FROM stats")
    suspend fun deleteAll()

    @Query("SELECT COUNT(*) FROM stats WHERE lotteryKey = :lotteryKey")
    suspend fun countByLottery(lotteryKey: String): Int
}
