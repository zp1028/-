package com.caifenxi.app.data.db.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable

/**
 * 模拟下注订单。
 * 方向类(大小/单双/组合):betValue 存方向文字,如 "大" / "单" / "大单"
 * 数字类(PK10 位置+号码):betValue 存 "位置名=号码",如 "冠军=5"
 */
@Entity(
    tableName = "bets",
    indices = [Index(value = ["lotteryKey", "issue"])]
)
@Serializable
data class BetEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val lotteryKey: String,          // 彩种 key
    val issue: String,               // 目标期号
    val sourceType: String,          // algo / plan / consensus
    val sourceId: String,            // 算法 id / 计划 id / "consensus"
    val category: String,            // 大小 / 单双 / 组合 / 数字
    val betValue: String,            // 方向文字 或 "位置=号码"
    val amount: Double,              // 单注金额(本金)
    val odds: Double,                // 赔率
    val status: String = "待开",     // 待开 / 中 / 未中
    val profit: Double = 0.0,        // 盈亏(中=amount*(odds-1),未中=-amount)
    val createdAt: Long = System.currentTimeMillis(),
    val settledAt: Long? = null
)
