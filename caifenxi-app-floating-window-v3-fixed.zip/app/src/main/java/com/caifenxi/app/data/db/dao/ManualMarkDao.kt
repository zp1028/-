package com.caifenxi.app.data.db.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.caifenxi.app.data.db.entity.ManualMarkEntity

@Dao
interface ManualMarkDao {
    @Query("SELECT * FROM manual_marks WHERE lotteryKey = :lotteryKey")
    suspend fun getByLottery(lotteryKey: String): List<ManualMarkEntity>

    @Query("SELECT * FROM manual_marks ORDER BY lotteryKey ASC")
    suspend fun getAll(): List<ManualMarkEntity>

    @Query("SELECT * FROM manual_marks WHERE lotteryKey = :lotteryKey AND category = :category LIMIT 1")
    suspend fun getByLotteryAndCategory(lotteryKey: String, category: String): ManualMarkEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(mark: ManualMarkEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(marks: List<ManualMarkEntity>)

    @Query("DELETE FROM manual_marks WHERE lotteryKey = :lotteryKey")
    suspend fun deleteByLottery(lotteryKey: String)

    @Query("DELETE FROM manual_marks")
    suspend fun deleteAll()

    @Query("SELECT COUNT(*) FROM manual_marks WHERE lotteryKey = :lotteryKey")
    suspend fun countByLottery(lotteryKey: String): Int
}
