package com.caifenxi.app.domain.engine

import com.caifenxi.app.CaiFenXiApplication
import com.caifenxi.app.data.config.ConsensusStore
import com.caifenxi.app.data.config.StatStore
import com.caifenxi.app.data.db.dao.BetDao
import com.caifenxi.app.data.db.dao.DrawDao
import com.caifenxi.app.domain.model.DrawRecord
import com.caifenxi.app.domain.plan.PlanEngine
import kotlinx.serialization.json.Json

/**
 * 开奖 / 战绩 / 共识 / 挂机 数据一致性校验与修复。
 *
 * 检查项:
 * 1. 开奖表同彩种期号重复
 * 2. 战绩「待开」但开奖已存在 → 应结算
 * 3. 共识「待开」但开奖已到达 → 应结算
 * 4. 挂机「待开」但开奖已到达 → 应结算
 * 5. 最新开奖后缺少下期待开共识
 * 6. 钱包余额与已结算注盈亏粗校验(仅报告,不强制改余额)
 */
object DataConsistency {

    data class Issue(
        val level: Level,
        val code: String,
        val message: String,
        val count: Int = 1
    )

    enum class Level { INFO, WARN, ERROR }

    data class Report(
        val lotteryKey: String,
        val issues: List<Issue>,
        val repaired: List<String>
    ) {
        val errorCount get() = issues.count { it.level == Level.ERROR }
        val warnCount get() = issues.count { it.level == Level.WARN }
        val ok get() = issues.none { it.level == Level.ERROR }

        fun summary(): String {
            if (issues.isEmpty()) return "一致性校验通过"
            return buildString {
                append("错误${errorCount} 警告${warnCount}")
                if (repaired.isNotEmpty()) append(" · 已修复${repaired.size}项")
            }
        }
    }

    private val json = Json { ignoreUnknownKeys = true }

    /**
     * @param repair true 时自动补结算/补生成下期共识
     */
    suspend fun checkAndRepair(
        lotteryKey: String,
        history: List<DrawRecord>,
        repair: Boolean = true
    ): Report {
        val app = CaiFenXiApplication.instance
        val issues = mutableListOf<Issue>()
        val repaired = mutableListOf<String>()

        if (history.isEmpty()) {
            issues += Issue(Level.WARN, "NO_HISTORY", "无开奖历史,跳过深度校验")
            return Report(lotteryKey, issues, repaired)
        }

        val byIssue = history.associateBy { it.issue }
        val issueNums = history.mapNotNull { it.issue.toLongOrNull() }
        val latest = history.last()

        // 1) 期号重复(按字符串)
        val dupIssues = history.groupBy { it.issue }.filter { it.value.size > 1 }
        if (dupIssues.isNotEmpty()) {
            issues += Issue(
                Level.ERROR,
                "DUP_DRAW_ISSUE",
                "开奖期号重复: ${dupIssues.keys.take(5).joinToString()}",
                dupIssues.size
            )
        }

        // 2) 战绩待开应结算
        val statPending = app.statStore.loadAll(lotteryKey).filter { it.result == "待开" }
        val statShouldSettle = statPending.filter { r ->
            byIssue.containsKey(r.issue) || issueNums.any { n ->
                val p = r.issue.toLongOrNull() ?: return@any false
                n >= p
            }
        }
        if (statShouldSettle.isNotEmpty()) {
            issues += Issue(
                Level.WARN,
                "STAT_PENDING_STALE",
                "战绩有 ${statShouldSettle.size} 条待开但开奖已到达",
                statShouldSettle.size
            )
            if (repair) {
                StatsEngine.settleWithDraws(app.statStore, lotteryKey, history)
                repaired += "战绩补结算 ${statShouldSettle.size} 条"
            }
        }

        // 3) 共识待开应结算
        val consPending = app.consensusStore.loadAll(lotteryKey).filter { it.result == "待开" }
        val consShouldSettle = consPending.filter { r ->
            byIssue.containsKey(r.targetIssue) || issueNums.any { n ->
                val p = r.targetIssue.toLongOrNull() ?: return@any false
                n >= p
            }
        }
        if (consShouldSettle.isNotEmpty()) {
            issues += Issue(
                Level.WARN,
                "CONSENSUS_PENDING_STALE",
                "共识有 ${consShouldSettle.size} 条待开但开奖已到达",
                consShouldSettle.size
            )
            if (repair) {
                ConsensusEngine.settleWithDraws(app.consensusStore, lotteryKey, history)
                repaired += "共识补结算 ${consShouldSettle.size} 条"
            }
        }

        // 4) 挂机待开应结算
        val betDao = app.database.betDao()
        val allBets = betDao.getBets(lotteryKey)
        val betPending = allBets.filter { it.status == "待开" }
        val betShouldSettle = betPending.filter { b ->
            byIssue.containsKey(b.issue) || issueNums.any { n ->
                val p = b.issue.toLongOrNull() ?: return@any false
                n >= p
            }
        }
        if (betShouldSettle.isNotEmpty()) {
            issues += Issue(
                Level.WARN,
                "BET_PENDING_STALE",
                "挂机有 ${betShouldSettle.size} 注待开但开奖已到达",
                betShouldSettle.size
            )
            if (repair) {
                // 按期号排序逐期结算,保证倍投/余额顺序正确
                val drawsToApply = betShouldSettle
                    .mapNotNull { byIssue[it.issue] }
                    .distinctBy { it.issue }
                    .sortedBy { it.issue.toLongOrNull() ?: 0L }
                for (d in drawsToApply) {
                    app.betEngine.settleWithDraw(lotteryKey, d)
                }
                // 无精确 draw 对象的期:用 history 中 >= 的第一期
                val remaining = betDao.getBets(lotteryKey).filter { it.status == "待开" }
                for (b in remaining) {
                    val d = history.firstOrNull { issueReached(b.issue, it.issue) } ?: continue
                    app.betEngine.settleWithDraw(lotteryKey, d)
                }
                repaired += "挂机补结算 ${betShouldSettle.size} 注"
            }
        }

        // 5) 下期共识是否存在
        val nextIssue = latest.nextIssue?.takeIf { it.isNotBlank() && it != latest.issue }
            ?: PredictEngine.suggestNextIssue(latest.issue)
        if (nextIssue.isNotBlank() && nextIssue != "-") {
            val nextPending = app.consensusStore.loadAll(lotteryKey)
                .filter { it.targetIssue == nextIssue && it.result == "待开" }
            if (nextPending.isEmpty()) {
                issues += Issue(
                    Level.WARN,
                    "NEXT_CONSENSUS_MISSING",
                    "缺少下期($nextIssue)待开共识"
                )
                if (repair && history.size >= 10) {
                    try {
                        val prefs = app.configStore.loadPrefs()
                        val preds = app.planEngine.predictForNext(
                            history, prefs, nextIssue, latest.issue
                        )
                        if (preds.isNotEmpty()) {
                            val cons = app.planEngine.consensus(lotteryKey, nextIssue, preds)
                            if (cons.isNotEmpty()) {
                                ConsensusEngine.recordPending(
                                    app.consensusStore, lotteryKey, nextIssue, cons
                                )
                                repaired += "已生成下期共识 $nextIssue (${cons.size}类)"
                            }
                        }
                    } catch (e: Exception) {
                        issues += Issue(
                            Level.ERROR,
                            "NEXT_CONSENSUS_GEN_FAIL",
                            "生成下期共识失败: ${e.message?.take(40)}"
                        )
                    }
                }
            }
        }

        // 6) 钱包粗校验: 已结算盈亏合计 vs wallet.totalProfit
        val wallet = betDao.getWallet(lotteryKey)
        if (wallet != null) {
            val settledProfit = allBets.filter { it.status != "待开" }.sumOf { it.profit }
            val diff = kotlin.math.abs(settledProfit - wallet.totalProfit)
            if (diff > 0.05) {
                issues += Issue(
                    Level.INFO,
                    "WALLET_PROFIT_MISMATCH",
                    "钱包累计盈亏(${"%.2f".format(wallet.totalProfit)})与注单合计(${"%.2f".format(settledProfit)})差 ${"%.2f".format(diff)}"
                )
            }
            // 待开占用: balance + pendingAmount 应接近 initial + totalProfit (新扣款模型)
            val pendingAmt = allBets.filter { it.status == "待开" }.sumOf { it.amount }
            val expectedApprox = wallet.initialBalance + wallet.totalProfit - pendingAmt
            // 旧数据可能未扣款,仅 INFO
            val balDiff = kotlin.math.abs(wallet.balance - expectedApprox)
            if (pendingAmt > 0 && balDiff > wallet.initialBalance * 0.01 + 1.0) {
                issues += Issue(
                    Level.INFO,
                    "WALLET_BALANCE_MODEL",
                    "余额与(初始+盈亏-待开本金)偏差较大,可能含旧版未扣款数据"
                )
            }
        }

        // 7) 计划引擎内存待结算 vs 开奖
        try {
            app.planEngine.settlePendingWithDraw(latest, app.configStore.loadPrefs().backtestParams)
        } catch (_: Exception) {
        }

        return Report(lotteryKey, issues, repaired)
    }

    private fun issueReached(pred: String, draw: String): Boolean {
        if (pred == draw) return true
        val a = pred.toLongOrNull()
        val b = draw.toLongOrNull()
        return a != null && b != null && a <= b
    }
}
