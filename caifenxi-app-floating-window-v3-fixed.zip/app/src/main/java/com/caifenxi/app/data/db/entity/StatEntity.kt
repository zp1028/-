package com.caifenxi.app.data.db.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import com.caifenxi.app.domain.model.StatRecord
import kotlinx.serialization.Serializable
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

@Entity(
    tableName = "stats",
    indices = [
        Index(value = ["lotteryKey", "issue", "category"], unique = true),
        Index(value = ["lotteryKey", "createdAt"])
    ]
)
@Serializable
data class StatEntity(
    @PrimaryKey val id: String,
    val lotteryKey: String,
    val issue: String,
    val category: String,
    val lean: String,
    val candidatesJson: String,
    val actual: String?,
    val result: String,
    val algoId: String,
    val score: Double,
    val matchMode: String,
    val createdAt: Long,
    val settledAt: Long?
) {
    fun toDomain(): StatRecord = StatRecord(
        id = id,
        lotteryKey = lotteryKey,
        issue = issue,
        category = category,
        lean = lean,
        candidates = Json.decodeFromString<List<String>>(candidatesJson),
        actual = actual,
        result = result,
        algoId = algoId,
        score = score,
        matchMode = matchMode,
        createdAt = createdAt,
        settledAt = settledAt
    )

    companion object {
        fun fromDomain(record: StatRecord): StatEntity = StatEntity(
            id = record.id,
            lotteryKey = record.lotteryKey,
            issue = record.issue,
            category = record.category,
            lean = record.lean,
            candidatesJson = Json.encodeToString<List<String>>(record.candidates),
            actual = record.actual,
            result = record.result,
            algoId = record.algoId,
            score = record.score,
            matchMode = record.matchMode,
            createdAt = record.createdAt,
            settledAt = record.settledAt
        )
    }
}
